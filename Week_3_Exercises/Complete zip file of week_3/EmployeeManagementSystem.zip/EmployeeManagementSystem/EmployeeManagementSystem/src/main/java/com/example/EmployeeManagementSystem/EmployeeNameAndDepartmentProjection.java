package com.example.EmployeeManagementSystem;

public interface EmployeeNameAndDepartmentProjection {
    String getName();
    String getDepartmentName();
}
